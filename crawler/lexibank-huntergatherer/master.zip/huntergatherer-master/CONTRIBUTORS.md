# Contributors

Name | GitHub user | Description | Role
--- | --- | --- | ---
Claire Bowern | | | Author, Editor
Patience Epps | | | Author, Editor
Jane Hill | | | Author, Editor
Patrick McConvell | | | Author, Editor
Robert Forkel | @xrotwang | code | Other
Christoph Rzymski | @chrzyki | patron | Other
Johann-Mattis List | @lingulist | orthography profile | Other
